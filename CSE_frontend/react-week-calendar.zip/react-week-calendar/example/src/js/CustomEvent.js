import React from 'react';

const customEvent = () => (
  <div className="customEvent">BOOKED</div>
);

export default customEvent;
