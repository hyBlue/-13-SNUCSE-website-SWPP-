import React from 'react';

const customHeaderCell = () => (
  <span>Some day in Furute</span>
);

export default customHeaderCell;
