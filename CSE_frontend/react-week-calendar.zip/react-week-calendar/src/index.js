import WeekCalendar from './WeekCalendar';

export default WeekCalendar;
